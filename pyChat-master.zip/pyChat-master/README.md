# pyChat
Chat con Pythton Flask
1. Edicion del fichero readme.md por primera vez
Para probar la funcionalidad de las ramas
